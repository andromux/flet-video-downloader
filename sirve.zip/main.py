import flet as ft
import logging
from pathlib import Path
from yt_dlp import YoutubeDL
from yt_dlp.utils import DownloadError
import os
import flet_video as fv
import asyncio

logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')

class VideoDownloader:
    def __init__(self, page: ft.Page):
        self.page = page
        self.carpeta_descargas = self.obtener_carpeta_descargas()
        self.videos_cache = None
        self.archivos_cache = []
        self.lista_control = ft.Column(spacing=10)

        self.url_field = ft.TextField(label="URL del video", hint_text="https://www.youtube.com/watch?v=...", prefix_icon=ft.Icons.LINK, expand=True)
        self.name_field = ft.TextField(label="Nombre del archivo", hint_text="mi_video", prefix_icon=ft.Icons.DRIVE_FILE_RENAME_OUTLINE, expand=True)
        self.progress_bar = ft.ProgressBar(width=600, visible=False)
        self.status_text = ft.Text()
        self.download_button = ft.ElevatedButton("Descargar", on_click=self.iniciar_descarga)
        self.clear_button = ft.TextButton("Limpiar", on_click=self.limpiar_campos)
        self.refresh_button = ft.TextButton("🔁 Actualizar lista", on_click=self.actualizar_videos)

    def obtener_carpeta_descargas(self) -> Path:
        carpeta = Path.home() / "Videos"
        if not carpeta.exists():
            carpeta = Path.home() / "Downloads"
        carpeta.mkdir(parents=True, exist_ok=True)
        return carpeta

    def listar_videos(self):
        return sorted([f for f in self.carpeta_descargas.glob("*.*") if f.suffix in ['.mp4', '.mkv', '.webm', '.mov']])

    def opciones_yt_dlp(self, ruta_salida: Path) -> dict:
        return {
            'format': 'bv*+ba/b',
            'outtmpl': str(ruta_salida),
            'noplaylist': True,
            'progress_hooks': [self.progreso_descarga],
        }

    def progreso_descarga(self, d):
        if d['status'] == 'finished':
            self.status_text.value = "✅ Descarga completada"
            self.progress_bar.value = 1.0
        elif d['status'] == 'downloading':
            percent = d.get('_percent_str', '0%').replace('%', '')
            try:
                percent_float = float(percent)
                eta = d.get('_eta_str', '...')
                self.status_text.value = f"Descargando: {percent}% - ETA: {eta}"
                self.progress_bar.value = percent_float / 100
            except:
                self.status_text.value = "Descargando..."
        self.progress_bar.visible = True
        self.page.update()

    def iniciar_descarga(self, e):
        url = self.url_field.value.strip()
        nombre = self.name_field.value.strip()

        if not url:
            self.status_text.value = "❌ URL requerida"
            self.page.update()
            return
        if not nombre:
            self.status_text.value = "❌ Nombre requerido"
            self.page.update()
            return

        ruta = self.carpeta_descargas / f"{nombre}.%(ext)s"
        opciones = self.opciones_yt_dlp(ruta)

        def tarea():
            try:
                self.estado_controles(False)
                with YoutubeDL(opciones) as ydl:
                    ydl.download([url])
                self.status_text.value = "🎉 ¡Descarga completada exitosamente!"
                self.progress_bar.value = 1.0
                self.videos_cache = None
                self.archivos_cache.clear()
            except DownloadError as e:
                self.status_text.value = f"❌ Error: {e}"
                self.progress_bar.value = 0
            except Exception as ex:
                self.status_text.value = f"❌ Excepción: {ex}"
                self.progress_bar.value = 0
            finally:
                self.progress_bar.visible = True
                self.estado_controles(True)
                self.page.update()

        self.page.run_thread(tarea)

    def limpiar_campos(self, e):
        self.url_field.value = ""
        self.name_field.value = ""
        self.status_text.value = ""
        self.progress_bar.visible = False
        self.page.update()

    def estado_controles(self, habilitar: bool):
        self.url_field.disabled = not habilitar
        self.name_field.disabled = not habilitar
        self.download_button.disabled = not habilitar
        self.page.update()

    async def vista_archivos(self):
        await self.actualizar_videos()
        return ft.Column([
            ft.Row([ft.Text("📂 Lista de videos", size=20, weight=ft.FontWeight.BOLD), self.refresh_button]),
            self.lista_control
        ], expand=True)

    async def actualizar_videos(self, e=None):
        archivos_actuales = self.listar_videos()
        if archivos_actuales == self.archivos_cache and self.videos_cache:
            return

        self.lista_control.controls.clear()
        for archivo in archivos_actuales:
            fila = ft.ListTile(
                title=ft.Text(archivo.name),
                trailing=ft.Icon(ft.Icons.PLAY_ARROW),
                on_click=lambda e, ruta=archivo: self.abrir_reproductor(ruta)
            )
            self.lista_control.controls.append(fila)

        self.archivos_cache = archivos_actuales
        self.videos_cache = True
        self.page.update()

    def abrir_reproductor(self, archivo: Path):
        video_overlay = fv.Video(
            expand=True,
            playlist=[fv.VideoMedia(archivo.as_uri())],
            aspect_ratio=16/9,
            volume=100,
            autoplay=True,
            filter_quality=ft.FilterQuality.MEDIUM,
            show_controls=True
        )
        dialog = ft.AlertDialog(
            open=True,
            title=ft.Text(archivo.name),
            content=video_overlay,
            actions=[ft.TextButton("Cerrar", on_click=lambda e: self.page.close(dialog))],
            modal=True,
            actions_alignment=ft.MainAxisAlignment.END
        )
        self.page.dialog = dialog
        self.page.open(dialog)

    def vista_descarga(self):
        return ft.Column([
            ft.Text("🎥 Descargador de Videos", size=24, weight=ft.FontWeight.BOLD),
            ft.Text(f"📁 Carpeta de descarga: {self.carpeta_descargas}"),
            self.url_field,
            self.name_field,
            ft.Row([self.download_button, self.clear_button]),
            self.progress_bar,
            self.status_text
        ], spacing=20)

async def main(page: ft.Page):
    page.title = "Flet Video Downloader"
    page.theme_mode = ft.ThemeMode.SYSTEM
    page.scroll = ft.ScrollMode.ADAPTIVE
    page.padding = 10

    downloader = VideoDownloader(page)

    def cambiar_tema(dark):
        page.theme_mode = ft.ThemeMode.DARK if dark else ft.ThemeMode.LIGHT
        page.update()

    archivos_view = await downloader.vista_archivos()

    tabs = ft.Tabs(
        selected_index=0,
        animation_duration=300,
        tabs=[
            ft.Tab(text="Descargar", content=downloader.vista_descarga()),
            ft.Tab(text="Mis Videos", content=archivos_view),
            ft.Tab(
                text="Ajustes",
                content=ft.Column([
                    ft.Switch(
                        label="🌙 Modo Oscuro",
                        value=page.theme_mode == ft.ThemeMode.DARK,
                        on_change=lambda e: cambiar_tema(e.control.value)
                    )
                ])
            )
        ]
    )

    page.add(tabs)

ft.app(target=main)
